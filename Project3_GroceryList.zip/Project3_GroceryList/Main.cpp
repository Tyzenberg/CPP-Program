/*
Developer: Tyler Lever
Date: 04/16/2023
Purpose: Read Grocery List and report frequency
*/


#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <iomanip>
#include "GroceryItem.h"
using namespace std;

//Display Main Menu
void MainMenuDisplay() {
	cout << "-------------------------------------" << endl;
	cout << "Please select an option below:" << endl;
	cout << "[1] Search for an Item." << endl;
	cout << "[2] Print list with numerical values." << endl;
	cout << "[3] Print list as histogram." << endl;
	cout << "[4] Quit." << endl;
	cout << "-------------------------------------" << endl;
}

vector <GroceryItem> BuildList() {
	
	//File variables
	string fileName;
	string filePath;
	string fileFullName;
	ifstream inFS;
	string fileItem;

	//List Variables
	bool duplicate = false;
	vector <string> itemNameList;
	vector <int> itemCountList;
	vector <GroceryItem> groceryList;
	GroceryItem tempItem;
	int i;

	//Designate Input File Name
	fileName = "CS210_Project_Three_Input_File.txt";
	filePath = "C:\\Users\\Tyler\\Desktop\\SNHU\\CS-210";
	fileFullName = filePath + "\\" + fileName;

	//Attempt to open file, inform user to contact support if file doesn't open
	inFS.open(fileFullName);
	if (!inFS.is_open()) {
		cout << "Could not find input file" << endl;
		cout << "Contact Support" << endl;
	}

	//Read until end of input file
	while (!inFS.eof()) {
		inFS >> fileItem;
		for (i = 0; i < itemNameList.size(); ++i) {

			//Handling for duplicates in the Input File
			if (fileItem == itemNameList[i]) {
				duplicate = true;
				itemCountList[i] += 1;
			}
		}

		//Handling for new item
		if (!duplicate) {
			itemNameList.push_back(fileItem);
			itemCountList.push_back(1);
		}

		//Reset duplicate boolean to false
		duplicate = false;
	}

	inFS.close();		//close input file

	//Use Name and Item List to build Object List
	for (i = 0; i < itemNameList.size(); ++i) {
		tempItem.SetName(itemNameList[i]);
		tempItem.IncreaseCount(itemCountList[i]);
		groceryList.push_back(tempItem);
	}

	return groceryList;
}

//Option 1: search by Item
void SearchItem(vector <GroceryItem> itemList) {
	string item;
	int i;
	bool found = false;

	cout << "What item would you like to see?" << endl;
	cin >> item;

	for (i = 0; i < itemList.size(); ++i) {												//Cycle through Item List
		if (itemList[i].GetName() == item) {											//Execute if item is found
			cout << itemList[i].GetName() << " = " << itemList[i].GetCount() << endl;	//Output of found item
			found = true;																//Item was found
		}
	}

	//Output if item is not found
	if (!found) {
		cout << "Could not find " << item << endl;
	}
}

//Option 2: Print list with numerical values
void PrintNumList(vector <GroceryItem> itemList) {
	int i;
	for (i = 0; i < itemList.size(); ++i) {
		cout << itemList[i].GetName() << " = " << itemList[i].GetCount() << endl;
	}
	cout << endl;
}

//Option 3: Print Histogram List
void PrintHistList(vector <GroceryItem> itemList) {
	int i;
	char symbol = '*';															//Adjust histogram symbol

	for (i = 0; i < itemList.size(); ++i) {
		cout << itemList[i].GetName() << " ";									//output name
		cout << setfill(symbol) << setw(itemList[i].GetCount()) << "" << endl;	//output number of symbols based on Item count
	}
	cout << endl;
}

int main() {
	int userChoice = 0;
	int i;
	ofstream outFS;
	vector <GroceryItem> objectList;

	outFS.open("frequency.dat");			//Open frequency.dat file
	objectList = BuildList();				//Use BuildList Function to create Grocery Object List

	//Write to the frequency.dat file from Grocery Object List
	for (i = 0; i < objectList.size(); ++i) {
		outFS << objectList[i].GetName() << " " << objectList[i].GetCount() << endl;
	}
	outFS.close();				//Close frequency.dat file

	//Display Main Menu untili user selects option 4 to quit
	while (userChoice != 4) {
		MainMenuDisplay();
		cin >> userChoice;
		if (userChoice == 1) {
			SearchItem(objectList);
		}
		else if (userChoice == 2) {
			PrintNumList(objectList);
		}
		else if (userChoice == 3) {
			PrintHistList(objectList);
		}
		else if (userChoice == 4) {
			cout << "Goodbye" << endl;
		}
		else {		//Catch for invalid input
			cout << "Invalid Input" << endl;
		}
	}
	return 0;
}