#include <iostream>
#include <string>
#include "GroceryItem.h"
using namespace std;
GroceryItem::GroceryItem() {
	itemName = "";
	itemCount = 0;
}

void GroceryItem::SetName(string name) {
	itemName = name;
}

void GroceryItem::IncreaseCount(int increase) {
	itemCount = increase;
}

string GroceryItem::GetName() {
	return itemName;
}

int GroceryItem::GetCount() {
	return itemCount;
}
