#define GroceryItem_H
#include <string>
#include <iostream>
using namespace std;
class GroceryItem {
public:
	GroceryItem();
	void SetName(string name);
	void IncreaseCount(int increase);
	string GetName();
	int GetCount();
private:
	string itemName;
	int itemCount;
};

